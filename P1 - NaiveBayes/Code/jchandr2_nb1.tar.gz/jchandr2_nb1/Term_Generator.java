import java.io.*;
import java.util.*;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.List;

public class Term_Generator 
{
	public
		List<String> terms = new ArrayList<String>();
		List<Integer> excellent = new ArrayList<Integer>();
		List<Integer> good = new ArrayList<Integer>();
		List<Integer> bad = new ArrayList<Integer>();
		
	public static String[] tokenize(String in)
	{
		String[] tokenized_sentence = null;
		tokenized_sentence = in.split(" ");
		return tokenized_sentence;
	}
	public static void fine_tokenize(List<String> t,Term_Generator x,int rating)
	{
		String[] stopwords = {"and","an","by","from","of","the","with","a","in"};
		int i;
		for(i=0;i<t.size();i++)
		{
			String temp = t.get(i);
			if(temp.endsWith(".") || temp.endsWith(",") || temp.endsWith("?") || temp.endsWith(";") || temp.endsWith("!") || temp.endsWith(":"))
				temp = temp.substring(0, temp.length()-1);
			
			if(Arrays.asList(stopwords).contains(temp))
				continue;
			
			temp = temp.replaceAll("\\?","");
			Pattern pt = Pattern.compile("[?\\W+]");
			Matcher mat = pt.matcher(temp);
			while(mat.find())
			{
				String s = mat.group();
				temp = temp.replaceAll(""+s, "");
			}
			
			if(temp.endsWith("ies") && !(temp.endsWith("eies")) && !(temp.endsWith("aies")))
				temp = temp.replaceAll("ies$", "y");
			else
				if(temp.endsWith("es") && !(temp.endsWith("aes")) && !(temp.endsWith("ees")) && !(temp.endsWith("oes")))
					temp = temp.replaceAll("es$", "e");
				else
					if(temp.endsWith("s") && !(temp.endsWith("us")) && !(temp.endsWith("ss")))
						temp = temp.replaceAll("s$","");
			
			if(temp.endsWith("\'"))
				temp = temp.substring(0, temp.length()-1);
			
			if(x.terms.contains(temp))
			{
				int index;
				index = x.terms.indexOf(temp);
				if (rating == 0) 
					x.excellent.set(index, x.excellent.get(index)+1);
				else
					if (rating == 1)
						x.good.set(index, x.good.get(index)+1);
					else
						if (rating == 2)
							x.bad.set(index, x.bad.get(index)+1);
			}
			else
			{
				x.terms.add(temp);
				if (rating == 0)
				{
					x.excellent.add(1);
					x.good.add(0);
					x.bad.add(0);
				}
				else
					if (rating == 1)
					{
						x.excellent.add(0);
						x.good.add(1);
						x.bad.add(0);
					}
					else
						if (rating == 2)
						{
							x.excellent.add(0);
							x.good.add(0);
							x.bad.add(1);
						}
			}
		}
	}
	
	public static void sort_terms(Term_Generator unsorted)
	{
		Term_Generator sorted = new Term_Generator();
		sorted.terms = new ArrayList<String>(unsorted.terms);
		java.util.Collections.sort(sorted.terms);
		int i;
		for(i=0;i < unsorted.terms.size();i++)
		{
			String temp = sorted.terms.get(i);
			int ind = unsorted.terms.indexOf(temp);
			sorted.excellent.add(i, unsorted.excellent.get(ind));
			sorted.good.add(i, unsorted.good.get(ind));
			sorted.bad.add(i, unsorted.bad.get(ind));
		}	
		unsorted.terms = new ArrayList<String>(sorted.terms);
		unsorted.excellent = new ArrayList<Integer>(sorted.excellent);
		unsorted.good = new ArrayList<Integer>(sorted.good);
		unsorted.bad = new ArrayList<Integer>(sorted.bad);
	}
	
	public static void main(String[] args) throws Exception
	{
		Term_Generator t = new Term_Generator();
		{
			if(args.length == 0)
				System.out.println(" No input file specified !!\n usage \"java Term_Generator input.txt\"");
			else
			{							
				String datafilename = args[0];
				Integer k = 0;
				Scanner infrmfile = new Scanner(new File(datafilename));
				List<String> lines = new ArrayList<String>();
				String[] arr = null;
				while (infrmfile.hasNextLine()) 
				{
					String temp = infrmfile.nextLine();
					temp = temp.toLowerCase();
					lines.add(temp);
					arr = lines.toArray(new String[k]);
					k++;
				}
				infrmfile.close();
				for(int i=0;i<arr.length;i++)
				{
					int sentence_rating = 0;
					String[] tokenized_sentence = null;
					tokenized_sentence = tokenize(arr[i]);
					if(tokenized_sentence[0].equals("excellent"))
						sentence_rating = 0;
					else
						if(tokenized_sentence[0].equals("good"))
							sentence_rating = 1;
						else
							sentence_rating = 2;
					tokenized_sentence = Arrays.copyOfRange(tokenized_sentence, 1, tokenized_sentence.length);
					List<String> token_list = Arrays.asList(tokenized_sentence);
					fine_tokenize(token_list,t,sentence_rating);
				}
				sort_terms(t);
				PrintWriter writer = new PrintWriter("output.txt");
				writer.println("Terms\t\t\t\tE\t\tG\t\tB");
				for(int i=0;i<t.terms.size();i++)
				{
					writer.println(t.terms.get(i)+"\t\t\t"+t.excellent.get(i)+"\t\t"+t.good.get(i)+"\t\t"+t.bad.get(i));
				}
				writer.close();
				System.out.println("Output file generated as output.txt");
			}
		}
	}
}