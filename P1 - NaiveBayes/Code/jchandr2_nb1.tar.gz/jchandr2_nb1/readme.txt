Readme for jchandr2_nb1

To run the code, execute these commands.

“make all” 	-> compiles and executes the code
“make output” 	-> shows the output
“make clean” 	-> deletes previous compilation and output.txt

The code extracts the keyword and and ranks in occurances in excellent,good and bad ratings. The code gets input from the user as the command line arguement. The document is split into an array of string where each string is a line of a document. The first word is truncated as it is the rank of the statement. Then it is sent to tokenize function where it tokenizes with a space as the splitter. It is returned as a string List to main. from main it is sent in string list to fine tokenize where it removes the special characters and stemms the sentence. Here, the rating for excellent, good and bad list are added and returned to the main. main sends it to sort function where the results are alphabatically sorted.
